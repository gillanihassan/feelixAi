import SectionOne from "../dashboardone/components/sectionOne/SectionOne";
import SectionTwo from "../dashboardone/components/sectiontwo/SectionTwo";
import SectionThree from "../dashboardone/components/sectionthree/SectionThree";

function DashboardOne() {
  return (
    <div>
      <SectionOne />
      <SectionTwo />
      <SectionThree />
    </div>
  );
}

export default DashboardOne;
