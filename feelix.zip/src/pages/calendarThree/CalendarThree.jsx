function CalendarThree() {
  return (
    <div>
      <h2>Calendar three</h2>
    </div>
  );
}

export default CalendarThree;
