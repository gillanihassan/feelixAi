import CalendarOne from "./calendarOne/CalendarSlot";

function Calender() {
  return (
    <div>
      <CalendarOne />
    </div>
  );
}

export default Calender;
