function CalendarSlot() {
  return (
    <div>
      <h2>Calender Solot One</h2>
    </div>
  );
}

export default CalendarSlot;
