import Navbar from "../homeTwo/components/navbar/Navbar";
import HeroSection from "./components/herosection/HeroSection";

function HomeTwo() {
  return (
    <div>
      <Navbar />
      <HeroSection />
    </div>
  );
}

export default HomeTwo;
